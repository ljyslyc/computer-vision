Annalise Hurst

My main.ipynb file contains all the code I used to create my results. To use it, open it as a Jupyter notebook and begin running the cells for each part of the assignment. Each part is labeled with a functions section and a main section. The main section is where you will enter your image(s) file path(s) and running it will produce the algorithms results to the output file paths specified. Make sure you run all of the cells in order, since later parts will used functions specified for earlier parts.
